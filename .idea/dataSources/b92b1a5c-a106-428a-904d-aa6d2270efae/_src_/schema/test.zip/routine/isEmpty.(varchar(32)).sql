CREATE FUNCTION isEmpty(parameter VARCHAR(32))
  RETURNS VARCHAR(20)
  BEGIN
	declare name VARCHAR(20);
	set name = 'false';
	return name;
	IF parameter is NULL THEN 
		return 'true';
	ELSEIF (parameter = '') THEN 
		return 'true';
	END IF;
	return 'false';
END;
